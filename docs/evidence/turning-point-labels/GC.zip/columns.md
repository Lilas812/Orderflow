# 転換点研究用の派生特徴

全特徴はtsSec未満のみ。結果・対照選択の未来参照は別扱い。CT17セッション、DST対応。Nは総数量・VPへ含め方向計算から除外。UNKNOWNを既知限月へ接続しない。

CSVは同一列、欠けは空欄＋missing_reasons。既知の0は0。対照のlabel=noneは反転しないという正解を保証しない。反応回数だけで売買優位性を示すものではない。

ボラ5分位は書出期間内の全適格秒の最近傍順位20/40/60/80%。同値は下の分位。ニアミス反転幅は元マーク前後15分全値幅の半分、切上げ最低1tick。秒内の順序が不明になる候補は反転判定から保守的に除外する。

CVDダイバージェンスのイベント順序ソートは300秒ずつ・最大10万レコード。超過時はその列だけ空欄（event_order_sort_budget）。親プロセスではソートしない。

- **row_type**: mark/random/nearmiss。対照は自動選択された比較点であり人の正解ラベルではない
- **matched_mark_id**: 元マークID
- **id**: 行ID
- **label**: 手動マークのみtop/bottom/failed、対照はnone
- **symbol**: NQ/GC
- **tsSec**: Unix秒（整数）
- **priceTicks**: 銘柄固有の整数ticks、NQ0.25/GC0.10
- **confidence**: 手動確信度1–3
- **note**: 手動メモ、先頭=+-@等はCSV式実行防止のためアポストロフィ付加
- **viewMode**: 手動時live/blind/hindsight。過去に本人が見た情報は保証しない。対照は空欄
- **screen**: 手動時heatmap/footprint。対照は空欄
- **expectedDirection**: 期待反転up/down
- **futureSeconds**: 作成時の最新受信済み市場データ時刻/再生位置とtsSecの差秒、最低0。編集では不変。対照は空欄
- **createdUs**: 手動作成Unixマイクロ秒
- **updatedUs**: 手動更新Unixマイクロ秒
- **contract**: 過去30分の原レコード限月。UNKNOWN/MIXEDは別表示し、未知の限月差を0で接続しない
- **quality**: complete/partial、およびcontract_unknown。未定義統計量とデータ欠けはmissing_reasonsで区別
- **missing_reasons**: 空欄列と理由のJSON。0は実際に計算できた0、欠けの代用ではない
- **session**: CT17–01 Asia /01–08 Europe /08–09 US open /09–14:30 US day /14:30–15 US close /other
- **minutes_from_ct17**: 実経過分。America/Chicago17:00起点、DST対応
- **minutes_from_us_open**: CT08:30（米国現物寄り）からの実経過分
- **rv_5m**: 過去300秒内の1秒終値変化の二乗和の平方根、ticks
- **rv_30m**: 過去1800秒内の1秒終値変化の二乗和の平方根、ticks
- **range_30m**: 過去1800秒の約定高値−安値、ticks
- **direction_30m**: 過去1800秒の(最終価格−最初の約定価格)/(高値−安値)、無単位
- **distance_session_high**: マーク価格−当セッション既知高値、ticks。CT17から完全な区間のみ
- **distance_session_low**: マーク価格−当セッション既知安値、ticks。CT17から完全な区間のみ
- **distance_previous_high**: マーク価格−直前の実在セッション高値、ticks。同限月の完全データのみ
- **distance_previous_low**: マーク価格−直前の実在セッション安値、ticks。同限月の完全データのみ
- **distance_poc**: マーク価格−セッションPOC、ticks。N含む数量。同量なら高価格
- **distance_vah**: マーク価格−70%VAH、ticks。上下隣接価格の大きい側、同量なら上
- **distance_val**: マーク価格−70%VAL、ticks
- **distance_round**: マーク価格−最寄りNQ100pt/GC10ドル、ticks。同距離は高い価格
- **buy_30s**: 直前30秒の買い主導枚数
- **sell_30s**: 直前30秒の売り主導枚数
- **delta_30s**: buy_30s−sell_30s
- **buy_60s**: 直前60秒の買い主導枚数
- **sell_60s**: 直前60秒の売り主導枚数
- **delta_60s**: buy_60s−sell_60s
- **buy_5m**: 直前300秒の買い主導枚数
- **sell_5m**: 直前300秒の売り主導枚数
- **delta_5m**: buy_5m−sell_5m
- **cvd_slope_10m**: 直前600個の秒末CVDを秒にOLS回帰した傾き×60、枚/分
- **cvd_divergence**: 過去10分の後半5分が前半5分より価格高値更新/CVD非更新(1)、安値更新/CVD非更新(-1)、その他0。極値の最初の実約定時点、時刻・sequence順
- **count_z_60s**: (最新60秒件数−それ以前29個の60秒件数の平均)/母標準偏差。偏差0は空欄
- **max_size_5m**: 過去300秒の個別約定最大枚数。N含む
- **sweep_seconds_5m**: 過去300秒で同方向主導の3以上の異なる価格がある秒数。買売両成立でも1秒
- **absorption_60s**: 期待反転が下なら買い、上なら売りの60秒枚数/(その方向への終値−初値の進行ticks、最低0、+1)
- **imbalance_1**: t−1秒の上位1段(bid−ask)/(bid+ask)
- **imbalance_5**: 同5段
- **imbalance_10**: 同10段
- **bid10_change_60s**: t−1秒とt−61秒の上位10段買い数量の差、枚
- **ask10_change_60s**: t−1秒とt−61秒の上位10段売り数量の差、枚
- **near_size**: t−1秒のマーク価格±2ticksの両側合計数量、枚
- **near_change_60s**: 同価格帯のt−1秒とt−61秒の数量差、枚
- **estimated_pull_60s**: 直前60秒、各側各価格のmax(0,前秒数量−当秒数量−同秒同価格の全約定枚数)の合計。取消の確定ではない
- **move_1m**: tから60秒未満の最終約定価格−マーク価格、ticks。符号は生の価格方向
- **move_5m**: 同300秒
- **move_15m**: 同900秒
- **favorable_15m**: 期待反転方向への最大進行、ticks、最低0
- **adverse_15m**: 期待反転と逆方向への最大進行、ticks、最低0
- **crossed_15m**: 期待反転と逆方向へマーク価格を1tick以上抜けたら1、それ以外0